import './App.css';
import QuoraMain from './Component/QuoraMain';

function App() {
  
  return (
    <>
    <QuoraMain />
    </>
  );
}

export default App;
