import React from 'react'
import SidebarOpt from './SidebarOpt';

export default function Sidebar() {
return (
    <div className='sidebar'>
        <SidebarOpt />
    </div>
);
}
